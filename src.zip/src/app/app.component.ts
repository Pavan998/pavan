import { Component } from '@angular/core';
import { CurrencyConverterService } from './currency-converter.service';
import { CustomerCareService } from './customer/customer-care.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html', //100 lines
  styleUrls: ['./app.component.css'] //100 lines
})
export class AppComponent {
  title = 'hello';
  constructor(private ccs: CurrencyConverterService,private custCare: CustomerCareService){
    
  }
  ngOnInit(){
    
    //this.ccs.updateCurreencies();
    //this.ccs.convert();
  }

  //100 lines code here
}


//Angular Component <-> Angular Service <-> Spring Controller <-> Spring Service <-->Spring Repo <->POJO<->TABLES

/*
 index.html
 -------------------------------
 <html>
    <app-root> </app-root>
    
 </html>


*/
import { TestBed } from '@angular/core/testing';

import { CustomerCareService } from './customer-care.service';

describe('CustomerCareService', () => {
  let service: CustomerCareService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomerCareService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomerCareService {

  constructor() { }
  phoneCalls(){alert('calling Customers'); }
  regiserComplaint(){alert('Regestering Customers Compliant'); }
}

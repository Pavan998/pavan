import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RegisterComponent } from './register/register.component';
import { SettingsContactComponent } from './settings-contact/settings-contact.component';
import { SettingsProfileComponent } from './settings-profile/settings-profile.component';
import { SettingsComponent } from './settings/settings.component';

const routes: Routes = [
  { path:'',redirectTo:"/home",pathMatch:'full'},
  { path:"home",component:HomeComponent },
  { path:"contactUs",component:ContactUsComponent },
  { path:"signin",component:LoginComponent },
  { path:"signup",component:RegisterComponent },

  { path:"settings",component:SettingsComponent,
    children:[
      { path:'',redirectTo:"profile",pathMatch:'full'},
      { path:"profile",component:SettingsProfileComponent },
      { path:"contact",component:SettingsContactComponent },
      { path:"**",component:PageNotFoundComponent }    
    ]
  },

  /*
localhost:4200/                  
localhost:4200/home              
localhost:4200/settings          
localhost:4200/settings/          - invoke profile
localhost:4200/settings/profile  
localhost:4200/settings/contact  
localhost:4200/settings/anyjunk  
localhost:4200/anyjunk           
*/

  { path:"**",component:PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

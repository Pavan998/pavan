import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-all-payee',
  templateUrl: './view-all-payee.component.html',
  styleUrls: ['./view-all-payee.component.css']
})
export class ViewAllPayeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

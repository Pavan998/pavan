import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonthlyStatmentComponent } from './monthly-statment/monthly-statment.component';
import { QuartelyStatmentComponent } from './quartely-statment/quartely-statment.component';
import { YearlyStatmentComponent } from './yearly-statment/yearly-statment.component';
import { CustomizedStatmentComponent } from './customized-statment/customized-statment.component';



@NgModule({
  declarations: [
    MonthlyStatmentComponent,
    QuartelyStatmentComponent,
    YearlyStatmentComponent,
    CustomizedStatmentComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    MonthlyStatmentComponent,
    YearlyStatmentComponent,
    QuartelyStatmentComponent,
    CustomizedStatmentComponent
  ]
})
export class BankStatmentModule { }

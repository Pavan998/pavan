import { ComponentFixture, TestBed } from '@angular/core/testing';

import { YearlyStatmentComponent } from './yearly-statment.component';

describe('YearlyStatmentComponent', () => {
  let component: YearlyStatmentComponent;
  let fixture: ComponentFixture<YearlyStatmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ YearlyStatmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(YearlyStatmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

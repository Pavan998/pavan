import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-yearly-statment',
  templateUrl: './yearly-statment.component.html',
  styleUrls: ['./yearly-statment.component.css']
})
export class YearlyStatmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

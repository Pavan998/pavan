import { TestBed } from '@angular/core/testing';

import { StatmentService } from './statment.service';

describe('StatmentService', () => {
  let service: StatmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StatmentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

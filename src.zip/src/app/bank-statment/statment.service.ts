import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StatmentService {

  constructor() { }
  statement(){
    alert('Statement is printing');
  }
}

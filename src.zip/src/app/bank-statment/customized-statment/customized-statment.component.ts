import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customized-statment',
  templateUrl: './customized-statment.component.html',
  styleUrls: ['./customized-statment.component.css']
})
export class CustomizedStatmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

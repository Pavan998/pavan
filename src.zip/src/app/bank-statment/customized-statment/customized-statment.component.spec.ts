import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomizedStatmentComponent } from './customized-statment.component';

describe('CustomizedStatmentComponent', () => {
  let component: CustomizedStatmentComponent;
  let fixture: ComponentFixture<CustomizedStatmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomizedStatmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomizedStatmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MonthlyStatmentComponent } from './monthly-statment.component';

describe('MonthlyStatmentComponent', () => {
  let component: MonthlyStatmentComponent;
  let fixture: ComponentFixture<MonthlyStatmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MonthlyStatmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MonthlyStatmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

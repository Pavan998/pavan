import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-monthly-statment',
  templateUrl: './monthly-statment.component.html',
  styleUrls: ['./monthly-statment.component.css']
})
export class MonthlyStatmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

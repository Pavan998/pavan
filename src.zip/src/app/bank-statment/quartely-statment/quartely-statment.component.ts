import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quartely-statment',
  templateUrl: './quartely-statment.component.html',
  styleUrls: ['./quartely-statment.component.css']
})
export class QuartelyStatmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

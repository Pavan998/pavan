import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuartelyStatmentComponent } from './quartely-statment.component';

describe('QuartelyStatmentComponent', () => {
  let component: QuartelyStatmentComponent;
  let fixture: ComponentFixture<QuartelyStatmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuartelyStatmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuartelyStatmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

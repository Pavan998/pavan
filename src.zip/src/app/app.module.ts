import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BankStatmentModule } from './bank-statment/bank-statment.module';
import { CurrencyConverterService } from './currency-converter.service';
import { CustomerCareService } from './customer/customer-care.service';
import { FundTransferModule } from './fund-transfer/fund-transfer.module';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import {HttpClientModule} from '@angular/common/http'
import {HttpClient} from '@angular/common/http'

@NgModule({
  declarations: [
    AppComponent, // we are declaring that AppComponent is one of the component of this module
    LoginComponent, RegisterComponent
  ],
  imports: [
    BrowserModule,  // for browser module to avail
    FormsModule,
    AppRoutingModule, // for routing of many pages during navigation (routing from one view to other view)
    BankStatmentModule,
    FundTransferModule,
    HttpClientModule
    
  ],
  providers: [CurrencyConverterService,CustomerCareService] ,// coming session we will provide service components here for spring controller to connect
  bootstrap: [AppComponent] //this would be launched as a bootstrap
})
export class AppModule { }// we are declaring that our AppModule is Angular's Module NOW with @NgModule decorator

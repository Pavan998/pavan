export class Customer{
    customerid: number|undefined;
    name: string|undefined
    city:string|undefined
    creditlimit: number|undefined;

}
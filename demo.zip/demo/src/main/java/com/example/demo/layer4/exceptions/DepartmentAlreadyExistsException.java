package com.example.demo.layer4.exceptions;



@SuppressWarnings("serial")
public class DepartmentAlreadyExistsException extends Throwable{
	public DepartmentAlreadyExistsException(String msg) {
		super(msg);
	}
}

package com.example.demo.layer2;

import java.sql.Date;

import java.util.HashSet;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;



//	 PK								  FK														
//  EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM     DEPTNO

@Entity
@Table(name="SYS_EMP")
public class Employee2 {
	
	@Id
	@Column(name="EMPNO")
	private int employeeNumber;
	
	@Column(name="ENAME", length=10)
	private String employeeName;
	
	@Column(name="JOB", length=9)	
	private String employeeJob;

	
	@Column(name="MGR",length=4)
	private Integer employeeManager;
	
	@Column(name="HIREDATE" )
	private Date employeeHiredate;
	
	@Column(name="SAL")
	private double employeeSalary;
	
	@Column(name="COMM",nullable = true)
	private Double employeeCommission; //wrapper
	
	@ManyToOne
	@JoinColumn(name="DEPTNO")
	private Department5 dept; 
	
	@OneToMany(mappedBy = "empobj", fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	Set<Customer2> custList = new HashSet<Customer2>();
	
	
	
	public Employee2() {
		super();
		System.out.println("Employee2() Ctor");
	}

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeJob() {
		return employeeJob;
	}

	public void setEmployeeJob(String employeeJob) {
		this.employeeJob = employeeJob;
	}

	public Integer getEmployeeManager() {
		return employeeManager;
	}

	public void setEmployeeManager(Integer employeeManager) {
		this.employeeManager = employeeManager;
	}

	public Date getEmployeeHiredate() {
		return employeeHiredate;
	}

	public void setEmployeeHiredate(Date employeeHiredate) {
		this.employeeHiredate = employeeHiredate;
	}

	public double getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public Double getEmployeeCommission() {
		return employeeCommission;
	}

	public void setEmployeeCommission(Double employeeCommission) {
		this.employeeCommission = employeeCommission;
	}

	@JsonIgnore
	public Department5 getDept() {
		return dept;
	}

	public void setDept(Department5 dept) {
		this.dept = dept;
	}

		
	public Set<Customer2> getCustList() {
		return custList;
	}

	public void setCustList(Set<Customer2> custList) {
		this.custList = custList;
	}

	/*
	 * @Override public String toString() { return "Employee2 [employeeNumber=" +
	 * employeeNumber + ", employeeName=" + employeeName + ", employeeJob=" +
	 * employeeJob + ", employeeManager=" + employeeManager + ", employeeHiredate="
	 * + employeeHiredate + ", employeeSalary=" + employeeSalary +
	 * ", employeeCommission=" + employeeCommission + "]"; }
	 */

	
	

	
	
	

	
	
}
package com.example.demo.layer5;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Department5;
import com.example.demo.layer2.Employee2;
import com.example.demo.layer4.DepartmentService;
import com.example.demo.layer4.exceptions.DepartmentAlreadyExistsException;
import com.example.demo.layer4.exceptions.DepartmentNotFoundException;

@RestController  //REpresentational State Transfer html xml json
public class DepartmentController {

	@Autowired
	DepartmentService deptServ;
	
	@GetMapping(path="/getDept/{mydno}")
	@ResponseBody
	public ResponseEntity<Department5> getDepartment(@PathVariable("mydno") Integer dno) throws DepartmentNotFoundException {
		System.out.println("Department Controller....Understanding client and talking to service layer...");
		Department5 dept=null;
		
			dept = deptServ.findDepartmentService(dno);
			if(dept==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(dept);
			}
		
	}
	
	
	@GetMapping(path="/getDepts")
	@ResponseBody
	public List<Department5> getAllDepartments() {
		System.out.println("Department Controller....Understanding client and talking to service layer...");
		List<Department5> deptList = deptServ.findDepartmentsService();
		return deptList;
		
	}
	
	@GetMapping(path="/getEmpsOfDept")
	@ResponseBody
	public Set<Employee2> getAllEmpsOfDept() {
		System.out.println("Department Controller....Understanding client and talking to service layer...");
		Department5 dept=null;
		try {
			dept = deptServ.findDepartmentService(30);
		} catch (DepartmentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Set<Employee2> empSet =dept.getEmpSet();
		return empSet;
		
	}
	
	@PostMapping(path="/addDept")
	public String addDepartment(@RequestBody Department5 dept) {
		System.out.println("Department Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = deptServ.addDepartmentService(dept);
		} 
		catch (DepartmentAlreadyExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		  return stmsg;
		
	}
	
	@PutMapping(path="/modifyDept")
	public String modifyDepartment(@RequestBody Department5 dept)throws DepartmentNotFoundException {
		System.out.println("Department Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = deptServ.modifyDepartmentService(dept);
		} 
		catch (DepartmentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		  return stmsg;
		
	}
	
	@DeleteMapping(path="/deleteDept")
	public String removeDepartment(@RequestBody Department5 dept)throws DepartmentNotFoundException {
		System.out.println("Department Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = deptServ.removeDepartmentService(dept.getDepartmentNumber());
		} 
		catch (DepartmentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		  return stmsg;
		
	}
	
}

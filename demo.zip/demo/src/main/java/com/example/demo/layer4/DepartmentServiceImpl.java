package com.example.demo.layer4;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.layer2.Department5;
import com.example.demo.layer3.DepartmentRepository;
import com.example.demo.layer4.exceptions.DepartmentAlreadyExistsException;
import com.example.demo.layer4.exceptions.DepartmentNotFoundException;

@Service
public class DepartmentServiceImpl implements DepartmentService {
		
	@Autowired
	DepartmentRepository deptRepo;
	
	@Override
	public String addDepartmentService(Department5 dRef) throws DepartmentAlreadyExistsException {
		System.out.println("Department Service....Some scope of bussiness logic here...");
		try {
			deptRepo.addDepartment(dRef);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new DepartmentAlreadyExistsException("Department already exists");
			
		}
		return "Department added successfully";
	}

	@Override
	public Department5 findDepartmentService(int dno) throws DepartmentNotFoundException {
		System.out.println("Department Service....Some scope of bussiness logic here...");
		return deptRepo.findDepartment(dno);
	}

	@Override
	public List<Department5> findDepartmentsService() {
		System.out.println("Department Service....Some scope of bussiness logic here...");
		return deptRepo.findDepartments();
	}

	@Override
	public String modifyDepartmentService(Department5 dRef)throws DepartmentNotFoundException {
		System.out.println("Department Service....Some scope of bussiness logic here...");
		
			Department5 d =deptRepo.findDepartment(dRef.getDepartmentNumber());
			if(d!=null)
			{deptRepo.modifyDepartment(dRef);}
			else {
				throw new DepartmentNotFoundException("Department Not Found");
			}
		 
		return "Department modified successfully";

	}

	@Override
	public String removeDepartmentService(int dno)throws DepartmentNotFoundException {
		Department5 d =deptRepo.findDepartment(dno);
		if(d!=null)
		{deptRepo.removeDepartment(d.getDepartmentNumber());}
		else {
			throw new DepartmentNotFoundException("Department Not Found");
		}
		return "Department Deleted successfully";
	}

}

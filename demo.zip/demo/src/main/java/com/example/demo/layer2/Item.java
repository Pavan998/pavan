package com.example.demo.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity(name="item")
public class Item {
	@Id
	@Column(name="ITEMID")
	private int itemId;
	
	@Column(name="PRODID")
	private int prodId;
	
	@Column(name="ACTUALPRICE")
	private double actualprice;
	
	@Column(name="QTY")
	private int quantity;
	
	@Column(name="ITEMTOT")
	private double total;
	
	@ManyToOne
	@JoinColumn(name="ORDID")
	private order ord;

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public double getActualprice() {
		return actualprice;
	}

	public void setActualprice(double actualprice) {
		this.actualprice = actualprice;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}
	@JsonIgnore
	public order getOrd() {
		return ord;
	}

	public void setOrd(order ord) {
		this.ord = ord;
	}
	
	
	

}

package com.example.demo.layer2;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="ord")
public class order {
	@Id
	@Column(name="ORDID")
	private int orderid;
	@Column(name="ORDERDATE")
	private Date orderdate;
	@Column(name="COMMPLAN")
	private String commplan;
	@Column(name="SHIPDATE")
	private Date shipdate;
	@Column(name="TOTAL")
	private double total;
	@ManyToOne
	@JoinColumn(name="CUSTID")
	private Customer2 Cust;
	@OneToMany(mappedBy = "ord", fetch = FetchType.EAGER, cascade = CascadeType.ALL )
	Set<Item> ItemSet = new HashSet<Item>();
	
	
	public order() {
		super();
		System.out.println("order() contr.....");
		
		
	}
	
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public Date getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(Date orderdate) {
		this.orderdate = orderdate;
	}
	public String getCommplan() {
		return commplan;
	}
	public void setCommplan(String commplan) {
		this.commplan = commplan;
	}
	public Date getShipdate() {
		return shipdate;
	}
	public void setShipdate(Date shipdate) {
		this.shipdate = shipdate;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	@JsonIgnore
	public Customer2 getCust() {
		return Cust;
	}
	public void setCust(Customer2 Cust) {
		this.Cust = Cust;
	}

	public Set<Item> getItemSet() {
		return ItemSet;
	}

	public void setItemSet(Set<Item> itemSet) {
		ItemSet = itemSet;
	}
	
	
	
}

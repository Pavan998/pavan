package com.example.demo.layer2.dto;



import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;




public class Department5DTO {
	
	
	
	 public String departmentName;
	
	 public String departmentLocation;
	
	
}
